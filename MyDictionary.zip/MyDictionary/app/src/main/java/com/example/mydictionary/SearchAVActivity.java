package com.example.mydictionary;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SearchAVActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_av);
        setTitle("Tìm kiếm A-V");
    }
}
